
var movie1 =[
    "Starwars a new hope",
     "1977",
     "George Lucas",
]
const movie2 =[
    "Pinapple Express",
     "2008",
    "David Green "
]
const movie3 =[
    "The Princess Bride",
    "1987",
    "Rob Reiner "
]
const movie4 =[
    "Akira",
    "1988",
    "Katsuhiro Otomo "
]
const movie5 =[
     "Bee Movie",
     "2007",
    "Simon Smith,Steve Hickner"
]

///// URL wasnt working for me professors, the sites kept denying me or wouldnt show up////////